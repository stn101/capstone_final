<?php


$servername = "hs35.name.com:21";
$database = "lrmpsmu_userTable";
$username = "lrmpsmu_newUser";
$password = "smusaints!";

// Create connection

$conn = mysqli_connect($servername, $username, $password, $database);

if($conn->connect_error){
    echo $conn->connect_error;
}
echo "Welcome to the Learning Resource Registration Form";
mysqli_close($conn);

?>
