<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lrmpsmu_wdpress' );

/** MySQL database username */
define( 'DB_USER', 'lrmpsmu_wdpress' );

/** MySQL database password */
define( 'DB_PASSWORD', '@[B3S2B7pg' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'u1dm7b4ihcxactx9udujc6h8rdgp3oknmiftuvdsaaepd3uwsbzz653al7hx4mj5' );
define( 'SECURE_AUTH_KEY',  'wbrpvpxh0adll6zzopetgaa7txuheahhee1muhmx2ofwx8aew3fkp39gpzilse9g' );
define( 'LOGGED_IN_KEY',    'zbyahrrsgl6nwfa6gmxgyinsdizzhw2sguuy1l4luodiebktruvza9pp4zmn3nn7' );
define( 'NONCE_KEY',        'tvw9qbvzi3ifbz9agrd4nkdm4rmcsbeq21mdxdhpxetvly9szg2qeeklbkhqx1hd' );
define( 'AUTH_SALT',        'bojwwspub8t7vchjqbtghljnifvsb0piqtitxkavpl98idrbpqblvgsqr84c5i8z' );
define( 'SECURE_AUTH_SALT', '4nuon51c0zkthrigohffofwor8hq0f8nnau0ruz0aj47t1egecsqfqcctske2ziv' );
define( 'LOGGED_IN_SALT',   'zrr2dneydmjqfp1dscjbjqdrusbcllfnsokyd64hmjmnpzen7tdaon4cpd4kisgy' );
define( 'NONCE_SALT',       'kta97lgxzkvbl6p9xij01gy8q3rziz0tiwgwmiv86upigxrjrihr5tlxrszqdwof' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpkg_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Multisite */
define( 'WP_ALLOW_MULTISITE', true );
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'www.stmartinlrmp.com');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
