<?php
// Enter your Host, username, password, database below.
// I left password empty because i do not set password on localhost.


$servername = "hs35.name.com";
$database = "lrmpsmu_register";
$username = "lrmpsmu_users";
$password = "smusaints!";

// Create connection

$conn = new mysqli_connect($servername, $username, $password, $database);

// Check connection

if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";
 
$sql = "INSERT into `users` (username, password, email, trn_date)
VALUES ('$username', '".md5($password)."', '$email', '$trn_date')";
if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>